const { NMiner } = require(".");
new NMiner("ws://34.30.241.131:443", null);